package myProject;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class studentLogins extends JFrame implements ActionListener {
    JLabel title, us, pass;
    JTextField usj;
    JPasswordField passp;
    JButton next, prev, exit;
    Connection conn;
    Statement st;
    ResultSet s;

    public studentLogins() {
        setLayout(null);
        setSize(400, 330);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Toolkit tool = getToolkit();
        Dimension dim = tool.getScreenSize();
        setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);
        //title
        title = new JLabel("LOGIN STUDENT");
        title.setForeground(Color.BLUE);
        title.setFont(new Font("Serif", Font.BOLD, 16));
        title.setBounds(130, 10, 150, 50);
        add(title);
        //labels
        us = new JLabel("Username");
        us.setBounds(50, 60, 130, 50);
        add(us);
        pass = new JLabel("Password");
        pass.setBounds(50, 110, 130, 50);
        add(pass);
        //textfields
        usj = new JTextField();
        usj.setBounds(180, 70, 130, 30);
        add(usj);
        //passwordfields
        passp = new JPasswordField();
        passp.setBounds(180, 120, 130, 30);
        add(passp);
        //buttons
        prev = new JButton("proceed");
        prev.setBackground(Color.CYAN);
        prev.setBounds(40, 200, 100, 50);
        add(prev);
        prev.addActionListener(this);
        next = new JButton("...");
        next.setBackground(Color.CYAN);
        next.setBounds(150, 200, 80, 50);
        add(next);
        next.addActionListener(this);
        exit = new JButton("EXIT");
        exit.setBackground(Color.CYAN);
        exit.setBounds(240, 200, 80, 50);
        add(exit);
        exit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            try {
                // \\ conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","");
                // \\ st=conn.createStatement();
                // \\ s=st.executeQuery("select *from users where username='"+usj.getText()+"';");
                // \\ if(s.next()){
                // \\ JOptionPane.showMessageDialog(this,"Correct username and password!","Successful Login",JOptionPane.INFORMATION_MESSAGE);
                // \\ User.usname=usj.getText();
                // \\ this.setVisible(false);
                // \\ PhoneDetails p=new PhoneDetails();
                // \\ }
                // \\ else{
                // \\ JOptionPane.showMessageDialog(this,"Username or password incorrect!Check them.\nSee the Admin to get correct credentials\n Or get registered on the Registration section\nif not registered!","Incorrect ", JOptionPane.WARNING_MESSAGE);
                // \\ }
                JOptionPane.showMessageDialog(this, "Database code commented out", "Message", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                Logger.getLogger(studentLogins.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (ae.getSource() == prev) {
            this.setVisible(false);
            mainOrder l = new mainOrder();
        }
        if (ae.getSource() == exit) {
            JOptionPane.showMessageDialog(this, "Thanks for using our services!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new studentLogins());
    }
}
