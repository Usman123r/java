package myProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;
import java.sql.*;

/**
 *
 * @author M.Ryan
 */
public class mainOrder extends JFrame implements ActionListener,ItemListener{
JLabel title, sit, no;
JTextField sij, noj;
JButton order, prev,exit;  
JComboBox sitc;
Connection conn;
Statement st,st2;
String [] dr={"smokis","eggs","smocha","rolex"};
public mainOrder(){
setLayout(null);
setSize(448,448);
setVisible(true);
    getContentPane().setBackground(Color.BLUE);
setDefaultCloseOperation(EXIT_ON_CLOSE);
Toolkit tool=getToolkit();
Dimension dim=tool.getScreenSize();
setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
//title
title=new JLabel("PASS YOUR COMMAND");
title.setForeground(Color.GREEN);
title.setFont(new Font("Serif",Font.BOLD,17));
title.setBounds(176, 9, 178, 48);
add(title);
//labels
sit=new JLabel("Select food");
sit.setBounds(100, 60, 130, 50);
add(sit);
no=new JLabel("Number");
no.setBounds(100, 210, 130, 50);
add(no);
//adding textfields
sij=new JTextField();
sij.setBounds(210, 120, 140, 30);
add(sij);
noj=new JTextField();
noj.setBounds(210, 220, 140, 30);
add(noj);
//adding of buttons
prev=new JButton("PREVIOUS");
prev.setBackground(Color.pink);
prev.setBounds(75, 320, 100, 50);
add(prev);
prev.addActionListener(this);
order=new JButton("...");
order.setBackground(Color.pink);
order.setBounds(190, 320, 80, 50);
add(order);
order.addActionListener(this);
exit=new JButton("order");
exit.setBackground(Color.pink);
exit.setBounds(285, 320, 80, 50);
add(exit);
exit.addActionListener(this);
//combobox
sitc=new JComboBox(dr);
sitc.setBounds(210, 70, 140, 30);
add(sitc);
sitc.addItemListener(this);
}

    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==exit){
    JOptionPane.showMessageDialog(this,"thanks for ur order we'll bring it in a few!","Exit",JOptionPane.INFORMATION_MESSAGE);
    this.setVisible(false);
    } 
    if(ae.getSource()==prev){
        this.setVisible(false);
        studentLogins o=new studentLogins();
    }
    if(ae.getSource()==order){
      int a;
      a=Integer.parseInt(noj.getText());
      User.no_item=a;
      User.total+=User.prix*a;
        try {
            conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","");
            st=conn.createStatement();
            st.executeUpdate("insert into orders values('"+User.usname+"',"+User.no_item+"')");
        } catch (SQLException ex) {

        }
      
    }
    }

    @Override
    public void itemStateChanged(ItemEvent ie) {
     if(ie.getSource()==sitc){
       sij.setText(sitc.getSelectedItem().toString());
       User.item=sitc.getSelectedItem().toString();
         Label pricej = null;
         if(sitc.getSelectedIndex()==0){
          User.prix=250;
          pricej.setText("250");
       }
       else if(sitc.getSelectedIndex()==1){
          User.prix=140;
          pricej.setText("140");
       }else if(sitc.getSelectedIndex()==2){
          User.prix=250;
          pricej.setText("250");
       }else{
          User.prix=160;
          pricej.setText("160");
       }
     }
    }}
