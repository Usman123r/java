package myProject;

import java.awt.event.ActionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;


public class MainWindow extends JFrame implements ActionListener{
    Icon ic;
    JLabel j, title;
    JButton nextet;
    public MainWindow(){
    //initial settings
    setLayout(null);
    getContentPane().setBackground(Color.BLUE);
    setTitle("siwakaBusiness");
    setSize(400,600);
    setVisible(true);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    Toolkit tool=getToolkit();
    Dimension dim=tool.getScreenSize();
    setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
    //labels
        j = new JLabel();
        j.setBounds(50, 50, 300, 300); // Adjusted size and position
        ImageIcon ic = new ImageIcon("C:\\Users\\Seraphin Ntumwa\\Downloads\\smocha.jpg"); // Corrected path
        Image img = ic.getImage().getScaledInstance(j.getWidth(), j.getHeight(), Image.SCALE_SMOOTH); // Scale the image
        ic = new ImageIcon(img);
        j.setIcon(ic);
        add(j);
    title=new JLabel("WELCOME TO SIWAKA BUSINESS");
    title.setForeground(Color.BLACK);
    title.setFont(new Font("Serif",Font.BOLD,16));
        title.setBounds(50, 10, 300, 50);
    add(title);
    //buttons
    nextet=new JButton("NEXT");
    nextet.setBackground(Color.GRAY);
    nextet.setBounds(200, 350, 100, 50);
    add(nextet);
    nextet.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==nextet){
    JOptionPane.showMessageDialog(this,"CLICK NEXT TO GO TO THE NEXT OPTIONS!!!","Welcome!",JOptionPane.INFORMATION_MESSAGE);
    this.setVisible(false);
    Registration r=new Registration();
    }
    }

}
