package myProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;

public class ViewOrders extends JFrame implements ActionListener{
JLabel title, us, it, noit, ph;
JTextField usj, itj, noitj, phj;
JButton prevo, nexto, gob, exit;  
Connection conn;
Statement st;
ResultSet rs;
public ViewOrders() throws SQLException{
setLayout(null);
setSize(450,470);
setVisible(true);
setDefaultCloseOperation(EXIT_ON_CLOSE);
Toolkit tool=getToolkit();
Dimension dim=tool.getScreenSize();
setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
//title
title=new JLabel("VIEW ORDERS");
title.setForeground(Color.BLUE);
title.setFont(new Font("Serif",Font.BOLD,16));
title.setBounds(180, 10, 180, 50);
add(title);
//labels
us=new JLabel("Username");
us.setBounds(100, 60, 130, 50);
add(us);
it=new JLabel("Item");
it.setBounds(100, 110, 130, 50);
add(it);
noit=new JLabel("Number of Items");
noit.setBounds(100, 160, 130, 50);
add(noit);
//textfields
usj=new JTextField();
usj.setBounds(210, 70, 140, 30);
add(usj);
itj=new JTextField();
itj.setBounds(210, 120, 140, 30);
add(itj);
noitj=new JTextField();
noitj.setBounds(210, 170, 140, 30);
add(noitj);
phj=new JTextField();
phj.setBounds(210, 220, 140, 30);
add(phj);
//buttons
prevo=new JButton("PREVIOUS ORDER");
prevo.setBackground(Color.CYAN);
prevo.setBounds(75, 290, 150, 50);
add(prevo);
prevo.addActionListener(this);
nexto=new JButton("NEXT ORDER");
nexto.setBackground(Color.CYAN);
nexto.setBounds(240, 290, 130, 50);
add(nexto);
nexto.addActionListener(this);
gob=new JButton("GO BACK");
gob.setBackground(Color.CYAN);
gob.setBounds(75, 360, 150, 45);
add(gob);
gob.addActionListener(this);
exit=new JButton("EXIT");
exit.setBackground(Color.CYAN);
exit.setBounds(240, 360, 130, 45);
add(exit);
exit.addActionListener(this);
conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase","root","");
st=conn.createStatement();
rs=st.executeQuery("select *from new_orders");

}

    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==exit){
    JOptionPane.showMessageDialog(this,"Thanks for using our services!","Exit",JOptionPane.INFORMATION_MESSAGE);
    this.setVisible(false);
    } 
    if(ae.getSource()==prevo){
    try {
            rs.previous();
            usj.setText(rs.getString("username"));
            itj.setText(rs.getString("item"));
            noitj.setText(rs.getString("no_item"));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"Beginning of Table!","No element found!!",JOptionPane.WARNING_MESSAGE);
    }
    }
    if(ae.getSource()==nexto){
        try {
            rs.next();
            usj.setText(rs.getString("username"));
            itj.setText(rs.getString("item"));
            noitj.setText(rs.getString("no_item"));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,"End of Table!","Cannot continue!",JOptionPane.WARNING_MESSAGE);
        }
    
    }
    if(ae.getSource()==gob){
    this.setVisible(false);
    ManageOrders mo=new ManageOrders();
    }
    
    }
 }

