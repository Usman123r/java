package myProject;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class deleteOrders extends JFrame implements ActionListener {
    JLabel title;
    JTextField nameField;
    JButton deleteButton, exitButton, previousButton;
    Connection conn;
    Statement stmt;

    public deleteOrders() throws SQLException {
        setTitle("Delete Orders");
        setLayout(null);
        setSize(350, 290);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Toolkit tool = getToolkit();
        Dimension dim = tool.getScreenSize();
        setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);

        // Title
        title = new JLabel("Enter Name of Client");
        title.setForeground(Color.BLACK);
        title.setFont(new Font("Serif", Font.PLAIN, 16));
        title.setBounds(90, 10, 180, 50);
        add(title);

        // Text field for name
        nameField = new JTextField();
        nameField.setBounds(80, 60, 160, 50);
        add(nameField);

        // Buttons
        deleteButton = new JButton("DELETE ORDER");
        deleteButton.setBackground(Color.CYAN);
        deleteButton.setBounds(180, 150, 120, 50);
        add(deleteButton);
        deleteButton.addActionListener(this);

        previousButton = new JButton("PREVIOUS");
        previousButton.setBackground(Color.CYAN);
        previousButton.setBounds(40, 150, 120, 50);
        add(previousButton);
        previousButton.addActionListener(this);

        exitButton = new JButton("EXIT");
        exitButton.setBackground(Color.CYAN);
        exitButton.setBounds(240, 150, 80, 50);
        add(exitButton);
        exitButton.addActionListener(this);

        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "root", "");
        stmt = conn.createStatement();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == deleteButton) {
            try {
                stmt.executeUpdate("DELETE FROM new_orders WHERE client_name = '" + nameField.getText() + "'");
                JOptionPane.showMessageDialog(this, "You have served the client!\nOrder successfully deleted!", "Delete Order", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException ex) {
                Logger.getLogger(deleteOrders.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (ae.getSource() == exitButton) {
            JOptionPane.showMessageDialog(this, "Thanks for using our services!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
        }
        if (ae.getSource() == previousButton) {
            this.setVisible(false);
            ManageOrders mo = new ManageOrders();
        }
    }
}
