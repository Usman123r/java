package myProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class userLogin extends JFrame implements ActionListener{
JLabel title;
JButton prev, exit, logst, loglec;
public userLogin(){
setLayout(null);
setSize(400,400);
setVisible(true);
setDefaultCloseOperation(EXIT_ON_CLOSE);
Toolkit tool=getToolkit();
Dimension dim=tool.getScreenSize();
setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
//title
title=new JLabel("LOGIN");
title.setForeground(Color.BLUE);
title.setFont(new Font("Serif",Font.BOLD,16));
title.setBounds(170, 10, 100, 50);
add(title);
//buttons
logst=new JButton("LOGIN STUDENT");
logst.setBounds(20, 80, 150, 100);
add(logst);
logst.addActionListener(this);
loglec=new JButton("LOGIN PERSONNEL");
loglec.setBounds(205, 80, 150, 100);
add(loglec);
loglec.addActionListener(this);
prev=new JButton("PREVIOUS");
prev.setBackground(Color.CYAN);
prev.setBounds(70, 230, 100, 50);
add(prev);
prev.addActionListener(this);
exit=new JButton("EXIT");
exit.setBackground(Color.CYAN);
exit.setBounds(220, 230, 100, 50);
add(exit);
exit.addActionListener(this);
}
    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==loglec){
    this.setVisible(false);
    staffLogins t=new staffLogins();
    }
    if(ae.getSource()==logst){
    this.setVisible(false);
    studentLogins ls=new studentLogins();
    }
    if(ae.getSource()==prev){
    this.setVisible(false);
    Registration r=new Registration();    
    }
    if(ae.getSource()==exit){
    JOptionPane.showMessageDialog(this,"Thanks for using our services!","Exit",JOptionPane.INFORMATION_MESSAGE);
    this.setVisible(false);
    }
        
    }
    
}
