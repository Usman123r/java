package myProject;


public class User {
 public static int prix=0, no_item=0, total;
 public static String usname;
 public static String item, phone;
 
}
