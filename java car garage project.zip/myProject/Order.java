package myProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * @author M.Ryan
 */
public class Order extends JFrame implements ActionListener{
JLabel title;
JButton yourOrder, prev, exit;
public Order(){
setLayout(null);
setSize(500,530);
    getContentPane().setBackground(Color.BLUE);
setVisible(true);
setDefaultCloseOperation(EXIT_ON_CLOSE);
Toolkit tool=getToolkit();
Dimension dim=tool.getScreenSize();
setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
//title
title=new JLabel("MENU");
title.setForeground(Color.BLUE);
title.setFont(new Font("Serif",Font.BOLD,16));
title.setBounds(220, 10, 100, 50);
add(title); 
//buttons

yourOrder=new JButton("view and order!");
yourOrder.setBounds(250, 70, 180, 150);
add(yourOrder);
yourOrder.addActionListener(this);
prev=new JButton("PREVIOUS");
prev.setBounds(60,420, 140,50);
prev.setBackground(Color.CYAN);
add(prev);
prev.addActionListener(this);
exit=new JButton("EXIT");
exit.setBounds(270,420, 140, 50);
exit.setBackground(Color.CYAN);
add(exit);
exit.addActionListener(this);

}
    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==prev){
        this.setVisible(false);
        studentLogins l=new studentLogins();
    }
    if(ae.getSource()==exit){
        JOptionPane.showMessageDialog(this,"Thanks for using our services!","Exit",JOptionPane.INFORMATION_MESSAGE);
        this.setVisible(false);
    } 

    if(ae.getSource()==yourOrder){
       this.setVisible(false);
       mainOrder d=new mainOrder();
    }
    if(ae.getSource()==yourOrder){
       this.setVisible(false);
    }

    }
    public static void main(String[] args) {
        // Run the Order class
        new Order();
    }
}
