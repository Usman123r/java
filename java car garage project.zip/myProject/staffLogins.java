package myProject;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class staffLogins extends JFrame implements ActionListener {
    JLabel title, us, pass;
    JTextField usj;
    JPasswordField passp;
    JButton next, prev, exit;
    Connection conn;
    Statement st;
    ResultSet s;

    public staffLogins() {
        setLayout(null);
        setSize(400, 330);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Toolkit tool = getToolkit();
        Dimension dim = tool.getScreenSize();
        setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);
        //title
        title = new JLabel("LOGIN PERSONNEL");
        title.setForeground(Color.BLUE);
        title.setFont(new Font("Serif", Font.BOLD, 16));
        title.setBounds(120, 10, 170, 50);
        add(title);
        //labels
        us = new JLabel("Username");
        us.setBounds(50, 60, 130, 50);
        add(us);
        pass = new JLabel("Password");
        pass.setBounds(50, 110, 130, 50);
        add(pass);
        //textfields
        usj = new JTextField();
        usj.setBounds(180, 70, 130, 30);
        add(usj);
        //passwordfields
        passp = new JPasswordField();
        passp.setBounds(180, 120, 130, 30);
        add(passp);
        //buttons
        prev = new JButton("PREVIOUS");
        prev.setBackground(Color.CYAN);
        prev.setBounds(40, 200, 100, 50);
        add(prev);
        prev.addActionListener(this);
        next = new JButton("NEXT");
        next.setBackground(Color.CYAN);
        next.setBounds(150, 200, 80, 50);
        add(next);
        next.addActionListener(this);
        exit = new JButton("EXIT");
        exit.setBackground(Color.CYAN);
        exit.setBounds(240, 200, 80, 50);
        add(exit);
        exit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            this.setVisible(false);
            // Open the ManageOrders window
            ManageOrders manageOrders = new ManageOrders();
        }
        if (ae.getSource() == prev) {
            this.setVisible(false);
            staffLogins l = new staffLogins();
        }
        if (ae.getSource() == exit) {
            JOptionPane.showMessageDialog(this, "Thanks for using our services!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new staffLogins());
    }
}
