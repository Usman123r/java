package myProject;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginSelections extends JFrame implements ActionListener {
    JButton regularLoginButton, studentLoginButton;

    public LoginSelections() {
        setTitle("Login Selection");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1));

        regularLoginButton = new JButton("Regular Login");
        regularLoginButton.addActionListener(this);
        add(regularLoginButton);

        studentLoginButton = new JButton("Student Login");
        studentLoginButton.addActionListener(this);
        add(studentLoginButton);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == regularLoginButton) {
            setVisible(false);
            new staffLogins();
        } else if (e.getSource() == studentLoginButton) {
            setVisible(false);
            new studentLogins();
            // Handle student login
        }
    }
}
