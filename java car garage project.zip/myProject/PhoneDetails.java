package myProject;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class PhoneDetails extends JFrame implements ActionListener {
JLabel title;
JTextField numberj;
JButton continu,exit;  
public PhoneDetails(){
setLayout(null);
    getContentPane().setBackground(Color.BLUE);
setSize(350,300);
setVisible(true);
setDefaultCloseOperation(EXIT_ON_CLOSE);
Toolkit tool=getToolkit();
Dimension dim=tool.getScreenSize();
setLocation(dim.width/2-getWidth()/2,dim.height/2-getHeight()/2);
//title
title=new JLabel("Enter your Phone Number : ");
title.setForeground(Color.BLACK);
title.setFont(new Font("Serif",Font.PLAIN,16));
title.setBounds(80, 10, 180, 50);
add(title);
//textfields
numberj=new JTextField();
numberj.setBounds(80, 60, 170, 50);
add(numberj);
//buttons
continu=new JButton("CONTINUE");
continu.setBackground(Color.CYAN);
continu.setBounds(110, 140, 100, 50);
add(continu);
continu.addActionListener(this);
}

    @Override
    public void actionPerformed(ActionEvent ae) {
    if(ae.getSource()==continu){
    this.setVisible(false);
    Order o=new Order();
    User.phone=numberj.getText();
    }    
    }
}
