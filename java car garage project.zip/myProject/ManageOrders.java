package myProject;

import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

public class ManageOrders extends JFrame implements ActionListener {
    JLabel title;
    JButton prev, exit, viewo, delo;

    public ManageOrders() {
        setLayout(null);
        setSize(400, 380);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Toolkit tool = getToolkit();
        Dimension dim = tool.getScreenSize();
        setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);
        // title
        title = new JLabel("MANAGE ORDERS");
        title.setForeground(Color.BLUE);
        title.setFont(new Font("Serif", Font.BOLD, 16));
        title.setBounds(130, 10, 150, 50);
        add(title);
        // buttons
        viewo = new JButton("VIEW ORDERS");
        viewo.setBounds(20, 80, 150, 100);
        add(viewo);
        viewo.addActionListener(this);
        delo = new JButton("DELETE ORDER");
        delo.setBounds(205, 80, 150, 100);
        add(delo);
        delo.addActionListener(this);
        prev = new JButton("PREVIOUS");
        prev.setBackground(Color.CYAN);
        prev.setBounds(70, 230, 100, 50);
        add(prev);
        prev.addActionListener(this);
        exit = new JButton("EXIT");
        exit.setBackground(Color.CYAN);
        exit.setBounds(220, 230, 100, 50);
        add(exit);
        exit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == prev) {
            this.setVisible(false);
            staffLogins t = new staffLogins();
        }
        if (ae.getSource() == viewo) {
            this.setVisible(false);
            try {
                ViewOrders vo = new ViewOrders();
            } catch (SQLException ex) {
                Logger.getLogger(ManageOrders.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (ae.getSource() == delo) {
            this.setVisible(false);
            try {
                deleteOrders de = new deleteOrders();
            } catch (SQLException ex) {
                Logger.getLogger(ManageOrders.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (ae.getSource() == exit) {
            JOptionPane.showMessageDialog(this, "Thanks for using our services!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ManageOrders());
    }
}
