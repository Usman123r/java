package myProject;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.logging.*;

public class Registration extends JFrame implements ActionListener, ItemListener {
    JLabel title, name, age, email;
    JTextField namej, agej, emailj;
    JButton clear, reg, login, exit;
    Connection conn;
    Statement st, st2;

    public Registration() {
        setLayout(null);
        setSize(550, 630);
        getContentPane().setBackground(Color.BLUE);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        Toolkit tool = getToolkit();
        Dimension dim = tool.getScreenSize();
        setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2 - getHeight() / 2);

        title = new JLabel("SIGN UP");
        title.setForeground(Color.GREEN);
        title.setFont(new Font("Serif", Font.BOLD, 15));
        title.setBounds(230, 9, 125, 45);
        add(title);

        name = new JLabel("Names");
        name.setBounds(147, 58, 96, 48);
        add(name);

        age = new JLabel("Age");
        age.setBounds(147, 105, 96, 48);
        add(age);

        email = new JLabel("E-mail address");
        email.setBounds(147, 160, 96, 48);
        add(email);

        namej = new JTextField();
        namej.setBounds(298, 68, 98, 28);
        add(namej);

        agej = new JTextField();
        agej.setBounds(298, 118, 98, 28);
        add(agej);

        emailj = new JTextField();
        emailj.setBounds(298, 168, 98, 28);
        add(emailj);

        clear = new JButton("undo");
        clear.setBackground(Color.pink);
        clear.setBounds(80, 520, 80, 50);
        add(clear);
        clear.addActionListener(this);

        reg = new JButton("REGISTER");
        reg.setBackground(Color.pink);
        reg.setBounds(180, 520, 100, 50);
        add(reg);
        reg.addActionListener(this);

        login = new JButton("LOGIN");
        login.setBackground(Color.pink);
        login.setBounds(300, 520, 80, 50);
        add(login);
        login.addActionListener(this);

        exit = new JButton("EXIT");
        exit.setBackground(Color.pink);
        exit.setBounds(400, 520, 80, 50);
        add(exit);
        exit.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == clear) {
            namej.setText("");
            agej.setText("");
            emailj.setText("");
        }
        if (ae.getSource() == reg) {
            try {
                // \\ conn=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/siwakaBusiness","root","");
                // \\ st=conn.createStatement();
                // \\ st.executeUpdate("insert into registration values('"+namej.getText()+"',"+Integer.parseInt(agej.getText())+",'"+emailj.getText()+"')");
                // \\ st2=conn.createStatement();
                // \\ st2.executeUpdate("insert into new_registration values('"+namej.getText()+"',"+Integer.parseInt(agej.getText())+",'"+emailj.getText()+"')");
                JOptionPane.showMessageDialog(this, "Data Saved!", "Successful Operation", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (ae.getSource() == login) {
            this.setVisible(false);
            new LoginSelections(); // Open the LoginSelection window
        }
        if (ae.getSource() == exit) {
            JOptionPane.showMessageDialog(this, "Thanks for using our services!", "Exit", JOptionPane.INFORMATION_MESSAGE);
            this.setVisible(false);
        }
    }

    @Override
    public void itemStateChanged(ItemEvent ie) {
        if (ie.getSource() == name) {
            String s;
            s = name.getPreferredSize().toString();
            namej.setText("" + s);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Registration());
    }
}
